import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs';
import { User } from './../models/app.user.model';

@Injectable()
export class UserService {
    url: string;
    constructor(private http: Http) {
        this.url = 'http://localhost:4040';
    }

    getLoginInfo(usr: User ): Observable<Response> {
        let resp: Observable<Response>;

        const header: Headers = new Headers({
          'Content-Type': 'application/json'
        });

        const options: RequestOptions = new RequestOptions();
        options.headers = header;

        resp = this.http.post(`${this.url}/api/users/auth`, JSON.stringify(usr), options);
        return resp;
    }

    getUserData(token: string): Observable<Response> {
        let resp: Observable<Response>;

        const header: Headers = new Headers({
            'Content-Type': 'application/json',
            'authorization' : 'bearer ' + token
        });
        const options: RequestOptions = new RequestOptions();
        options.headers = header;

        resp = this.http.get(`${this.url}/api/users`, options);
        return resp;
    }

      getUserDataByUserName(userName: string, token: string): Observable<Response> {
      console.log('In userService');
      let resp: Observable<Response>;
      console.log('Api api/user/userName going to hit for userName :' + userName);
      const header: Headers = new Headers({
          'Content-Type': 'application/json',
          'authorization' : 'bearer ' + token,
           'userName' : userName
      });

      console.log(JSON.stringify(header));
      const options: RequestOptions = new RequestOptions();
      options.headers = header;
      console.log('going to hit api/user/userName');
      resp = this.http.get(`${this.url}/api/user/userName`, options);
      // console.log('resp in service : ' + JSON.stringify(resp));
      return resp;
  }

    postUserData(usr: User, token: string): Observable<Response>{
      let resp: Observable<Response>;

      const header: Headers = new Headers({
        'Content-Type': 'application/json',
        'authorization': 'bearer ' + token
      });

      const options: RequestOptions = new RequestOptions();
      options.headers = header;

      resp = this.http.post(`${this.url}/api/users`, JSON.stringify(usr), options);
      return resp;
    }
}
