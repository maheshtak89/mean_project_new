import { Injectable } from '@angular/core';
import { CanActivate, Router, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';

@Injectable()
export class AppGuardService implements CanActivate {
    constructor(private _router: Router){ }
    canActivate(
      route: ActivatedRouteSnapshot,
      state: RouterStateSnapshot ): boolean {

      var isAllow = sessionStorage.getItem("token");

      if(isAllow == "" || isAllow == undefined) {
        alert("You are not allowed to View this page. You are redirected to Login page..!");
        this._router.navigate(["login"]);
        return false;
      } else{
        return true;
      }
      return null;
    }
}
