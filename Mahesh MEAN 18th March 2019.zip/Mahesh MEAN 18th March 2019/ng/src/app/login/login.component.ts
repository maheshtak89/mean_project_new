import { Component, OnInit } from '@angular/core';
import { User, Users } from "./../../models/app.user.model";
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { UserService } from 'src/services/UserService';
import { Router } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  token: string;
  user: User;
  message: string;
  frmLogin: FormGroup;

  constructor(private usrServ: UserService, private router: Router) {
    this.message = '';
    this.user = new User('', '', '', 0);

    this.frmLogin = new FormGroup({
                          userName: new FormControl(
                          this.user.userName,
                          Validators.compose([Validators.required])
      ),
      password: new FormControl(
                          this.user.password,
                          Validators.compose([Validators.required])
      )
    });
   }

  ngOnInit() {
  }

  signIn(): void{
    this.user = this.frmLogin.value;
    console.log(JSON.stringify(this.user));

      this.usrServ.getLoginInfo(this.user).subscribe(
          (resp) => {
              if(resp.json().token) {
                  sessionStorage.setItem('token', resp.json().token);
                  sessionStorage.setItem('userName', resp.json().userName);
                  sessionStorage.setItem('roleName',resp.json().roleName);
                  this.router.navigate(['dashboard/home']);
              } else {
                this.message = resp.json().message;
              }
          },
          error => {
            console.log(`Error Occured ${error}`);
          }
      )
  }
}
