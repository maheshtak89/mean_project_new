import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validator, Validators } from '@angular/forms';
import { Response } from "@angular/http";
import { Router } from '@angular/router';
import { PersonInfo } from "./../../models/app.create.user.model";

@Component({
  selector: 'app-personinfo',
  templateUrl: './personinfo.component.html',
  styleUrls: ['./personinfo.component.css']
})
export class PersoninfoComponent implements OnInit {

  person: PersonInfo;
  message: string;
  token: string;
  frmPerson: FormGroup;

  constructor() { }

  ngOnInit() {
  }

  save(){

  }

  clear(){

  }
}
