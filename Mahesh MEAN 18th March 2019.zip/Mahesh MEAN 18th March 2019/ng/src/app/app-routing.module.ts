import { NgModule, Component } from '@angular/core';

import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { UserComponent } from './user/user.component';
import { HomeComponent } from './home/home.component';
import { AppGuardService } from './../services/AppGuardService';
import { ListuserComponent } from './listuser/listuser.component';
import { PersoninfoComponent } from './personinfo/personinfo.component';
import { ViewRoleComponent } from './roles/view-role/view-role.component';
import { AddInfoComponent } from './add-info/add-info.component';
import { PendingComponent } from './pending/pending.component';
import { ApprovedComponent } from './approved/approved.component';
import { ProfileComponent } from './profile/profile.component';

// Define Route table
const routes: Routes = [
  { path: 'login', component: LoginComponent},
  { path: '', component: LoginComponent},
  {
    path: 'dashboard',
  component: DashboardComponent, canActivate: [AppGuardService],
  children: [
    {
      path: 'home',
      component: HomeComponent
    },
    {
      path: '',
      component: LoginComponent
    }
  ]},
  {
    path: 'user',
    component: UserComponent
  },

  {
    path: 'addInfo/:userName',
    component: AddInfoComponent
  },

  {
    path: 'listuser',
    component: ListuserComponent
  },
  {
    path: 'viewRole',
    component: ViewRoleComponent
  },
  {
    path: 'pending',
    component: PendingComponent
  },
  {
    path: 'approved',
    component: ApprovedComponent
  },

  {
    path: 'profile',
    component: ProfileComponent
  },

  {
    path: 'addRole',
    component: ViewRoleComponent
  },

  {
    path: 'reateperson',
    component: PersoninfoComponent
  },

  {
  path: '',
  redirectTo: '',
  pathMatch: 'full'
},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
