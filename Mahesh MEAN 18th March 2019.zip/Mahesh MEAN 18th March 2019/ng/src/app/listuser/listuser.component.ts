import { Component, OnInit } from '@angular/core';
import { User } from 'src/models/app.user.model';
import { FormGroup } from '@angular/forms';
import { UserService } from 'src/services/UserService';
import { Router, NavigationExtras, ActivatedRoute } from '@angular/router';
import { Response } from '@angular/http';

@Component({
  selector: 'app-listuser',
  templateUrl: './listuser.component.html',
  styleUrls: ['./listuser.component.css']
})
export class ListuserComponent implements OnInit {
  user: User;
  token: string;
  users: Array<User>;
  userHeaders: Array<string>;

  constructor(private userServ: UserService, private router: Router) {
    this.user = new User('', '', '', 0);
    this.users = new Array<User>();
    this.userHeaders = new Array<string>('UserName', 'Email');
    this.token = sessionStorage.getItem('token');
  }

  ngOnInit() {

      // for(let u in this.userHeaders){
      //     this.userHeaders.push(u);
      // }

      this.userServ.getUserData(this.token).subscribe(
        (resp: Response) => {
            this.users = resp.json().data;
            console.log(JSON.stringify(this.users));
        },
        error => {
          console.log(`Error Occured ${error}`);
        }
    );
  }

    addInfo(userName) {
      console.log('UserName is: ' + userName);
      this.updateInfo(userName);
    }
    updateInfo(userName) {
    const navigationExtras: NavigationExtras = {
          queryParams: {
              'userName': userName
          }
      };
      this.router.navigate(['addInfo'],navigationExtras);
    }
}
