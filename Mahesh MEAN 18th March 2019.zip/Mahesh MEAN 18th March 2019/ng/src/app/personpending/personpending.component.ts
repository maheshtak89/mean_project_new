import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personpending',
  templateUrl: './personpending.component.html',
  styleUrls: ['./personpending.component.css']
})
export class PersonpendingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
