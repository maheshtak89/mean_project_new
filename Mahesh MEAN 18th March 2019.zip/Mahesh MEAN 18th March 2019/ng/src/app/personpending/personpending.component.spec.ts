import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonpendingComponent } from './personpending.component';

describe('PersonpendingComponent', () => {
  let component: PersonpendingComponent;
  let fixture: ComponentFixture<PersonpendingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonpendingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonpendingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
